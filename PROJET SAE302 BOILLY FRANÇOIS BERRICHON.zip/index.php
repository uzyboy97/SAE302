<!DOCTYPE html>
<html>
<head>
  <title>Picshare</title>
  <link rel="stylesheet" href="/../styles.css">
  <script src="/../script.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Jomhuria&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
</head>
<body>
  <div class="menu">
    <div class="box">
      <img class="rectangle" alt="Rectangle" src="/asset/img/rectangle-1.png" />
      <img class="logo" alt="logo" src="/asset/img/picshare-low-resolution-logo-color-on-transparent-background.png" />
    </div>
    <div class="buttons">
      <button id="home-button" class="menu-button">Accueil</button>
      <button class="menu-button">Téléchargement</button>
      <a href="view.php" class="menu-button">Communautés</a>
    </div>
  </div>
  
  <div class="label3">
    <h3><span>
      Upload et Partage une image sans inscription !
    </span></h3>
  </div>

  <div id="Upload">
    <?php if (isset($_GET['error'])): ?>
<p><?php echo $_GET['error']; ?></p>
<?php endif ?>
     <form action="upload.php"
           method="post"
           enctype="multipart/form-data">

           <input type="file" 
                  name="my_image">

           <input type="submit" 
                  name="submit"
                  value="Upload">
    </form>
  </div>

  <div class="ou">
    <h4><span>
      Glisser-déposer vos fichiers n'importe où pour commencer l'envoi de vos images dès maintenant.
    </span></h4>
  </div>

  <script>
    document.getElementById("home-button").addEventListener("click", function() {
      window.location.href = "/../index.html";
    });
  </script>
</body>
</html>
