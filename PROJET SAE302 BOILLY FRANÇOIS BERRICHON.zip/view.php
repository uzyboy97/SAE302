<?php include "db_conn.php"; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Picshare</title>
        <link rel="stylesheet" href="styles.css">
        <script src="/../script.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Jomhuria&display=swap" rel="stylesheet">
        <meta charset="UTF-8">
        <style>
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
                min-height: 100vh;
            }
            
            .ald {
                width: 200px;
                height: 200px;
                padding: 5px;
                cursor: pointer;
            }
            
            .ald img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            
            a {
                text-decoration: none;
                color: black;
            }
            
            .modal {
                display: none;
                position: fixed;
                z-index: 9999;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.8);
                justify-content: center;
                align-items: center;
            }
            
            .modal-content {
                max-width: 80%;
                max-height: 80%;
            }
            
            .modal-content img {
                width: 50%;
                height: 50%;
                object-fit: contain;
            }
            
            .modal-buttons {
                display: flex;
                justify-content: center;
                margin-top: 10px;
            }
            
            .modal-buttons button {
                margin: 0 5px;
            }
            
            .close {
                position: absolute;
                top: 10px;
                right: 10px;
                font-size: 100px;
                cursor: pointer;
                color: white;
            }
            
            .label4 {
                display: flex;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 20px;
                text-align: center;
                color: #F5F5F5;
                text-align: center;
                text-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
                font-family: Jomhuria;
                font-size: 55px;
                font-style: normal;
                font-weight: 200;
                line-height: normal;
                padding: auto;
            }

            .gallery {  
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                align-items: center;
                margin-top: 20px;
            }

            .gallery .ald {
                margin-bottom: 600px;
            }

            .gallery .ald img {
                width: 200px;
                height: 200px;
                border-radius: 10px;
                object-fit: cover;
                cursor: pointer;
            }

        </style>
    </head>
    <body>
        <div class="menu">
            <div class="box">
                <img class="rectangle" alt="Rectangle" src="/asset/img/rectangle-1.png" />
            </div>
            <div class="buttons">
                <a href="index.html" class="menu-button">Accueil</a>
                <a href="index.php" class="menu-button">Téléchargement</a>
                <a href="view.php" class="menu-button">Communautés</a>
            </div>
        </div>
            <div class="label4">
                <h5><span>
                Téléchargez vos images en un seul clic et partagez-les avec le monde entier. Que ce soit des paysages époustouflants, des portraits captivants ou des moments de vie uniques, chaque photo a sa place sur Picshare. Rejoignez notre communauté passionnée de photographes et d'amateurs d'art visuel. Explorez, inspirez-vous et partagez vos histoires visuelles avec Picshare.
                Vous pouvez aussi les télécharger, c'est pas beau ça? 
                </span></h5>
        </div>
        
        

        <a href="index.php">&#8592;</a>
        <div class="gallery">
        <?php
            $sql = "SELECT * FROM images ORDER BY id DESC";
            $res = mysqli_query($conn, $sql);
            if (mysqli_num_rows($res) > 0) {
                while ($images = mysqli_fetch_assoc($res)) {  ?>
                
                <div class="ald" onclick="openModal('uploads/<?=$images['image_url']?>')">
                    <img src="uploads/<?=$images['image_url']?>" alt="Image">
                </div>
                
        <?php } }?>
        </div>
        
        <div id="myModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <div class="modal-content">
            <img id="modalImage" src="" alt="Modal Image">
            <div class="modal-buttons">
                <button onclick="downloadImage()">Télécharger</button>
        </div>
        
    </div>
</div>
        
        <script>
            function openModal(imageUrl) {
                var modal = document.getElementById("myModal");
                var modalImage = document.getElementById("modalImage");
                modal.style.display = "flex";
                modalImage.src = imageUrl;
            }
            
            function closeModal() {
                var modal = document.getElementById("myModal");
                modal.style.display = "none";
            }
            
            function downloadImage() {
                var modalImage = document.getElementById("modalImage");
                var link = document.createElement('a');
                link.href = modalImage.src;
                link.download = 'image.jpg';
                link.click();
            }
        </script>
    </body>
</html>