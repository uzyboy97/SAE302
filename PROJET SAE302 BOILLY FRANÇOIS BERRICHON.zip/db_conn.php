<?php  

$sname = "localhost";
$uname = "u437712833_admin";
$password = "MpJMqgWoE5!";

$db_name = "u437712833_picshares";

$conn = mysqli_connect($sname, $uname, $password, $db_name);

if (!$conn) {
	echo "Connection failed!" . mysqli_connect_error();
	exit();
} 
