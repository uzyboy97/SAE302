// Récupérer le bouton de redirection par son identifiant
const redirectionButton = document.getElementById('redirection-button');

// Ajouter un gestionnaire d'événements pour le clic sur le bouton
redirectionButton.addEventListener('click', () => {
  // Rediriger l'utilisateur vers la page de redirection
  window.location.href = 'redirection.html';
});
